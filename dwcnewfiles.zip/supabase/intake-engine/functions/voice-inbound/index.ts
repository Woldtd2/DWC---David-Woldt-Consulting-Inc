// Supabase Edge Function: voice-inbound
// Phase 1 (intake-engine) — answers Twilio inbound calls, routes to tenant, records
// the call + session, returns TwiML. See
// docs/specs/intake-engine-phase1-twilio-voice-webhook.md
//
// Deploy:  supabase functions deploy voice-inbound --no-verify-jwt
// Secrets: TWILIO_AUTH_TOKEN, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, PUBLIC_FN_URL
// Twilio:  set this function URL as the number's Voice webhook (POST) and statusCallback.
//
// Requires (Phase 1 migration): tenants.phone_number text unique.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { createHmac } from "node:crypto";

const env = (k: string, d = "") => Deno.env.get(k) ?? d;

// Twilio signature: base64( HMAC-SHA1( authToken, fullUrl + sorted(param+value) ) )
function validTwilioSignature(url: string, params: Record<string, string>, sig: string): boolean {
  const token = env("TWILIO_AUTH_TOKEN");
  if (!token) return false;
  const data = url + Object.keys(params).sort().map((k) => k + params[k]).join("");
  const expected = createHmac("sha1", token).update(Buffer.from(data, "utf-8")).digest("base64");
  // constant-time-ish compare
  if (expected.length !== sig.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ sig.charCodeAt(i);
  return diff === 0;
}

function twiml(body: string): Response {
  return new Response(`<?xml version="1.0" encoding="UTF-8"?><Response>${body}</Response>`, {
    headers: { "Content-Type": "text/xml" },
  });
}

function greeting(vertical: string | null): string {
  if (vertical === "funeral") {
    return `<Say voice="Polly.Joanna">Thank you for calling. We're here to help. ` +
           `Please tell me a little about how we can support you today.</Say>`;
  }
  return `<Say voice="Polly.Joanna">Thank you for calling. How can I help you today?</Say>`;
}

Deno.serve(async (req) => {
  const form = new URLSearchParams(await req.text());
  const params: Record<string, string> = {};
  for (const [k, v] of form) params[k] = v;

  const sig = req.headers.get("X-Twilio-Signature") ?? "";
  const url = env("PUBLIC_FN_URL") || req.url;
  if (!validTwilioSignature(url, params, sig)) {
    return new Response("invalid signature", { status: 403 });
  }

  const supabase = createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"));
  const callSid = params.CallSid;
  const to = params.To ?? "";
  const callStatus = params.CallStatus ?? "";

  // Lifecycle: statusCallback for completed calls just closes the session.
  if (callStatus === "completed" || callStatus === "no-answer" || callStatus === "failed") {
    await supabase.from("voice_sessions").upsert({
      call_sid: callSid,
      data: { status: callStatus, ended_at: new Date().toISOString() },
    }, { onConflict: "call_sid" });
    return twiml("");
  }

  // Resolve tenant by dialed number.
  const { data: tenant } = await supabase
    .from("tenants").select("name, vertical").eq("phone_number", to).maybeSingle();

  if (!tenant) {
    await supabase.from("voice_sessions").upsert({
      call_sid: callSid,
      data: { status: "unrouted", to, from: params.From, started_at: new Date().toISOString() },
    }, { onConflict: "call_sid" });
    return twiml(`<Say voice="Polly.Joanna">Thank you for calling. Please hold while we connect you.</Say>`);
  }

  // Record session (tenant-stamped so RLS scopes it) + the call row.
  await supabase.from("voice_sessions").upsert({
    call_sid: callSid,
    data: {
      tenant: tenant.name, vertical: tenant.vertical,
      from: params.From, to, status: "in-progress",
      started_at: new Date().toISOString(),
    },
  }, { onConflict: "call_sid" });

  await supabase.from("calls").insert({ tenant: tenant.name, vertical: tenant.vertical });

  // Phase 2 hook: replace <Say> follow-up with <Connect><Stream> or <Gather>.
  return twiml(greeting(tenant.vertical));
});
