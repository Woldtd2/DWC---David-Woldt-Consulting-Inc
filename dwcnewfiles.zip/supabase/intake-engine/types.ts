// Generated from Supabase project intake-engine (vbrwsdsauuuoyewfeyog).
// Regenerate with: supabase gen types typescript --project-id vbrwsdsauuuoyewfeyog
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  __InternalSupabase: { PostgrestVersion: "14.5" }
  public: {
    Tables: {
      audit_log: {
        Row: { call_id: string | null; created_at: string | null; id: number; line: string | null }
        Insert: { call_id?: string | null; created_at?: string | null; id?: number; line?: string | null }
        Update: { call_id?: string | null; created_at?: string | null; id?: number; line?: string | null }
        Relationships: [{ foreignKeyName: "audit_log_call_id_fkey"; columns: ["call_id"]; isOneToOne: false; referencedRelation: "calls"; referencedColumns: ["id"] }]
      }
      calls: {
        Row: { autonomy: string | null; created_at: string | null; grief_firewall: boolean | null; handoff: boolean | null; id: string; intent: string | null; priority: string | null; tenant: string; transcript: string | null; vertical: string }
        Insert: { autonomy?: string | null; created_at?: string | null; grief_firewall?: boolean | null; handoff?: boolean | null; id?: string; intent?: string | null; priority?: string | null; tenant: string; transcript?: string | null; vertical: string }
        Update: { autonomy?: string | null; created_at?: string | null; grief_firewall?: boolean | null; handoff?: boolean | null; id?: string; intent?: string | null; priority?: string | null; tenant?: string; transcript?: string | null; vertical?: string }
        Relationships: []
      }
      intake_records: {
        Row: { call_id: string | null; complete: boolean | null; fields: Json | null; id: string; intent_key: string | null }
        Insert: { call_id?: string | null; complete?: boolean | null; fields?: Json | null; id?: string; intent_key?: string | null }
        Update: { call_id?: string | null; complete?: boolean | null; fields?: Json | null; id?: string; intent_key?: string | null }
        Relationships: [{ foreignKeyName: "intake_records_call_id_fkey"; columns: ["call_id"]; isOneToOne: false; referencedRelation: "calls"; referencedColumns: ["id"] }]
      }
      intent_schemas: {
        Row: { created_at: string | null; intent_key: string; required_fields: string[]; vertical: string | null }
        Insert: { created_at?: string | null; intent_key: string; required_fields?: string[]; vertical?: string | null }
        Update: { created_at?: string | null; intent_key?: string; required_fields?: string[]; vertical?: string | null }
        Relationships: []
      }
      pending_actions: {
        Row: { action: string; autonomy: string | null; created_at: string | null; id: string; payload: Json | null; status: string | null; tenant: string }
        Insert: { action: string; autonomy?: string | null; created_at?: string | null; id?: string; payload?: Json | null; status?: string | null; tenant: string }
        Update: { action?: string; autonomy?: string | null; created_at?: string | null; id?: string; payload?: Json | null; status?: string | null; tenant?: string }
        Relationships: []
      }
      tenants: {
        Row: { created_at: string | null; id: string; name: string; vertical: string }
        Insert: { created_at?: string | null; id?: string; name: string; vertical: string }
        Update: { created_at?: string | null; id?: string; name?: string; vertical?: string }
        Relationships: []
      }
      voice_sessions: {
        Row: { call_sid: string; data: Json | null; updated_at: string | null }
        Insert: { call_sid: string; data?: Json | null; updated_at?: string | null }
        Update: { call_sid?: string; data?: Json | null; updated_at?: string | null }
        Relationships: []
      }
    }
    Views: { [_ in never]: never }
    Functions: {
      current_tenant: { Args: never; Returns: string }
    }
    Enums: { [_ in never]: never }
    CompositeTypes: { [_ in never]: never }
  }
}
