-- Multi-tenant isolation for intake-engine.
-- Tenant identity is taken from the JWT claim 'tenant'. Backend services use the
-- service_role key (which BYPASSES RLS); interactive/authenticated callers are
-- scoped to their own tenant. Closes the "RLS enabled, no policy" findings.

create or replace function public.current_tenant() returns text
language sql stable
set search_path = public
as $$ select nullif(coalesce(auth.jwt() ->> 'tenant', ''), '') $$;

comment on function public.current_tenant() is
  'Returns the caller tenant from JWT claim "tenant" (NULL if absent). Used by RLS policies.';

drop policy if exists tenants_tenant_scope on public.tenants;
create policy tenants_tenant_scope on public.tenants for all to authenticated
  using (name = public.current_tenant()) with check (name = public.current_tenant());

drop policy if exists calls_tenant_scope on public.calls;
create policy calls_tenant_scope on public.calls for all to authenticated
  using (tenant = public.current_tenant()) with check (tenant = public.current_tenant());

drop policy if exists pending_actions_tenant_scope on public.pending_actions;
create policy pending_actions_tenant_scope on public.pending_actions for all to authenticated
  using (tenant = public.current_tenant()) with check (tenant = public.current_tenant());

drop policy if exists intake_records_tenant_scope on public.intake_records;
create policy intake_records_tenant_scope on public.intake_records for all to authenticated
  using (exists (select 1 from public.calls c
                 where c.id = intake_records.call_id and c.tenant = public.current_tenant()))
  with check (exists (select 1 from public.calls c
                 where c.id = intake_records.call_id and c.tenant = public.current_tenant()));

drop policy if exists audit_log_tenant_read on public.audit_log;
create policy audit_log_tenant_read on public.audit_log for select to authenticated
  using (exists (select 1 from public.calls c
                 where c.id = audit_log.call_id and c.tenant = public.current_tenant()));

drop policy if exists voice_sessions_tenant_scope on public.voice_sessions;
create policy voice_sessions_tenant_scope on public.voice_sessions for all to authenticated
  using (coalesce(data->>'tenant','') = public.current_tenant())
  with check (coalesce(data->>'tenant','') = public.current_tenant());
