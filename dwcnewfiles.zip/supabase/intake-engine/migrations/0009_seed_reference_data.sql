-- Minimal, removable reference/demo data: one demo tenant + an intent catalog.
insert into public.tenants(name, vertical)
select 'demo-funeral-home', 'funeral'
where not exists (select 1 from public.tenants where name = 'demo-funeral-home');

insert into public.intent_schemas(intent_key, vertical, required_fields) values
  ('at_need_arrangement', 'funeral', array['deceased_name','date_of_death','contact_name','contact_phone','disposition_type']),
  ('pre_need_inquiry',    'funeral', array['contact_name','contact_phone','plan_interest']),
  ('price_quote',         'funeral', array['contact_name','contact_phone','service_type']),
  ('general_question',    'funeral', array['contact_name','contact_phone'])
on conflict (intent_key) do nothing;
