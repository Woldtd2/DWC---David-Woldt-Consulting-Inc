-- Phase 1 (Twilio voice webhook): map an inbound dialed number to a tenant.
-- Not yet applied to the live project — apply when building Phase 1.
alter table public.tenants add column if not exists phone_number text unique;

-- Example: point the demo tenant at its Twilio number once provisioned.
-- update public.tenants set phone_number = '+1XXXXXXXXXX' where name = 'demo-funeral-home';
