-- Catalog of intake field requirements per intent, and a trigger that marks an
-- intake_records row complete once all required fields are present in `fields`.

create table if not exists public.intent_schemas (
  intent_key text primary key,
  vertical text,
  required_fields text[] not null default '{}',
  created_at timestamptz default now()
);

alter table public.intent_schemas enable row level security;
drop policy if exists intent_schemas_read on public.intent_schemas;
create policy intent_schemas_read on public.intent_schemas for select to authenticated using (true);

create or replace function public.set_intake_complete() returns trigger
language plpgsql
set search_path = public
as $$
declare req text[];
begin
  select required_fields into req from public.intent_schemas where intent_key = new.intent_key;
  if req is null then
    new.complete := coalesce(new.complete, false);
  else
    new.complete := (new.fields is not null and new.fields ?& req);
  end if;
  return new;
end $$;

drop trigger if exists trg_intake_complete on public.intake_records;
create trigger trg_intake_complete
  before insert or update of fields, intent_key on public.intake_records
  for each row execute function public.set_intake_complete();
