-- Append-only audit trail for call and pending_action lifecycle changes.

create or replace function public.log_audit() returns trigger
language plpgsql
set search_path = public
as $$
begin
  if tg_table_name = 'calls' then
    insert into public.audit_log(call_id, line)
    values (new.id, format('call %s: intent=%s priority=%s autonomy=%s handoff=%s grief_firewall=%s',
            tg_op, new.intent, new.priority, new.autonomy, new.handoff, new.grief_firewall));
  elsif tg_table_name = 'pending_actions' then
    insert into public.audit_log(call_id, line)
    values (null, format('pending_action %s: action=%s status=%s autonomy=%s tenant=%s',
            tg_op, new.action, new.status, new.autonomy, new.tenant));
  end if;
  return new;
end $$;

drop trigger if exists trg_audit_calls on public.calls;
create trigger trg_audit_calls after insert or update on public.calls
  for each row execute function public.log_audit();

drop trigger if exists trg_audit_pending on public.pending_actions;
create trigger trg_audit_pending after insert or update on public.pending_actions
  for each row execute function public.log_audit();
