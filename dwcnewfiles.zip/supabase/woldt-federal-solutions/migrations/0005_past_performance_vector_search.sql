-- Semantic past-performance matching for capture/proposal reuse.
-- HNSW cosine index over the 1536-dim embedding + a search RPC.

create index if not exists past_performance_embedding_hnsw
  on public.past_performance using hnsw (embedding extensions.vector_cosine_ops);

create or replace function public.match_past_performance(
  query_embedding extensions.vector,
  match_count int default 10,
  filter_naics text default null
) returns table (
  pp_id text,
  contract_title text,
  customer text,
  role text,
  cpars_rating text,
  similarity double precision
)
language sql
stable
set search_path = public, extensions
as $$
  select pp.pp_id, pp.contract_title, pp.customer, pp.role, pp.cpars_rating,
         1 - (pp.embedding <=> query_embedding) as similarity
  from public.past_performance pp
  where pp.embedding is not null
    and (filter_naics is null or pp.naics ? filter_naics)
  order by pp.embedding <=> query_embedding
  limit match_count;
$$;

comment on function public.match_past_performance is
  'Cosine-similarity search over past_performance.embedding (vector 1536). '
  'filter_naics optionally restricts to rows whose naics jsonb array contains the code.';
