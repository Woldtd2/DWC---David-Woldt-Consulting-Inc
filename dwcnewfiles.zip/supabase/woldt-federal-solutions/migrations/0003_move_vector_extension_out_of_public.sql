-- Advisor fix: relocate pgvector out of the public schema.
-- 'extensions' is already in the database search_path, so the vector type,
-- operator classes, and the past_performance.embedding column keep resolving.
alter extension vector set schema extensions;
