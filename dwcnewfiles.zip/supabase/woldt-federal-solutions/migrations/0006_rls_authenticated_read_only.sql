-- RLS for woldt-federal-solutions (single-org internal capture/proposal tool).
-- authenticated (interactive staff) get READ-only; all writes go through backend
-- services using the service_role key (which bypasses RLS). Clears the
-- "RLS enabled, no policy" and "permissive RLS policy" advisor findings.
-- If interactive write access is later required for a specific table, add a scoped
-- write policy (e.g. gated on a role/claim) for it.
--
-- Supersedes the interim 0004 policy set (FOR ALL USING(true)).

do $$
declare t text;
begin
  foreach t in array array[
    'opportunities','solicitations','solicitation_pages','requirements',
    'compliance_findings','capture_profiles','past_performance','bid_runs'
  ] loop
    execute format('drop policy if exists %I on public.%I', t||'_authenticated_all', t);
    execute format('drop policy if exists %I on public.%I', t||'_authenticated_read', t);
    execute format(
      'create policy %I on public.%I for select to authenticated using (true)',
      t||'_authenticated_read', t);
  end loop;
end $$;
