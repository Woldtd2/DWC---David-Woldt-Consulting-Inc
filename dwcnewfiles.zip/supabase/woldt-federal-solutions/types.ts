// Generated from Supabase project woldt-federal-solutions (yivzkppqnclhfyjixzkh).
// Regenerate with: supabase gen types typescript --project-id yivzkppqnclhfyjixzkh
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  __InternalSupabase: { PostgrestVersion: "14.5" }
  public: {
    Tables: {
      bid_runs: {
        Row: { created_at: string; current_stage: string; gate_decisions: Json; log: Json; opportunity_id: string; pending_gate: string | null; state: Json; status: string; updated_at: string }
        Insert: { created_at?: string; current_stage?: string; gate_decisions?: Json; log?: Json; opportunity_id: string; pending_gate?: string | null; state?: Json; status?: string; updated_at?: string }
        Update: { created_at?: string; current_stage?: string; gate_decisions?: Json; log?: Json; opportunity_id?: string; pending_gate?: string | null; state?: Json; status?: string; updated_at?: string }
        Relationships: []
      }
      capture_profiles: {
        Row: { buyer: Json | null; competitors: Json | null; created_at: string; findings: Json | null; id: number; incumbent: Json | null; intel_gaps: Json | null; opportunity_id: string | null; posture_rationale: string | null; recommended_posture: string | null; teaming: Json | null; win_themes: Json | null }
        Insert: { buyer?: Json | null; competitors?: Json | null; created_at?: string; findings?: Json | null; id?: never; incumbent?: Json | null; intel_gaps?: Json | null; opportunity_id?: string | null; posture_rationale?: string | null; recommended_posture?: string | null; teaming?: Json | null; win_themes?: Json | null }
        Update: { buyer?: Json | null; competitors?: Json | null; created_at?: string; findings?: Json | null; id?: never; incumbent?: Json | null; intel_gaps?: Json | null; opportunity_id?: string | null; posture_rationale?: string | null; recommended_posture?: string | null; teaming?: Json | null; win_themes?: Json | null }
        Relationships: [{ foreignKeyName: "capture_profiles_opportunity_id_fkey"; columns: ["opportunity_id"]; isOneToOne: false; referencedRelation: "opportunities"; referencedColumns: ["notice_id"] }]
      }
      compliance_findings: {
        Row: { finding_id: string | null; id: number; message: string; related_req_ids: Json | null; severity: string; solicitation_id: number | null }
        Insert: { finding_id?: string | null; id?: never; message: string; related_req_ids?: Json | null; severity: string; solicitation_id?: number | null }
        Update: { finding_id?: string | null; id?: never; message?: string; related_req_ids?: Json | null; severity?: string; solicitation_id?: number | null }
        Relationships: [{ foreignKeyName: "compliance_findings_solicitation_id_fkey"; columns: ["solicitation_id"]; isOneToOne: false; referencedRelation: "solicitations"; referencedColumns: ["id"] }]
      }
      opportunities: {
        Row: { active: boolean | null; agency_path: string | null; base_type: string | null; classification_code: string | null; created_at: string; description_link: string | null; naics: string | null; notice_id: string; notice_type: string | null; place_of_performance: string | null; points_of_contact: Json | null; posted_date: string | null; raw: Json | null; response_deadline: string | null; response_deadline_tz_present: boolean | null; set_aside: string | null; set_aside_code: string | null; solicitation_number: string | null; source: string; title: string; ui_link: string | null }
        Insert: { active?: boolean | null; agency_path?: string | null; base_type?: string | null; classification_code?: string | null; created_at?: string; description_link?: string | null; naics?: string | null; notice_id: string; notice_type?: string | null; place_of_performance?: string | null; points_of_contact?: Json | null; posted_date?: string | null; raw?: Json | null; response_deadline?: string | null; response_deadline_tz_present?: boolean | null; set_aside?: string | null; set_aside_code?: string | null; solicitation_number?: string | null; source?: string; title: string; ui_link?: string | null }
        Update: { active?: boolean | null; agency_path?: string | null; base_type?: string | null; classification_code?: string | null; created_at?: string; description_link?: string | null; naics?: string | null; notice_id?: string; notice_type?: string | null; place_of_performance?: string | null; points_of_contact?: Json | null; posted_date?: string | null; raw?: Json | null; response_deadline?: string | null; response_deadline_tz_present?: boolean | null; set_aside?: string | null; set_aside_code?: string | null; solicitation_number?: string | null; source?: string; title?: string; ui_link?: string | null }
        Relationships: []
      }
      past_performance: {
        Row: { contract_title: string; cpars_rating: string | null; created_at: string; customer: string; embedding: string | null; naics: Json | null; outcomes: Json | null; partner_provided: boolean; period_end: string | null; period_start: string | null; pp_id: string; reference_consent: boolean; reference_contact: string | null; reference_name: string | null; role: string; scope_summary: string | null; scope_tags: Json | null; value_usd: number | null }
        Insert: { contract_title: string; cpars_rating?: string | null; created_at?: string; customer: string; embedding?: string | null; naics?: Json | null; outcomes?: Json | null; partner_provided?: boolean; period_end?: string | null; period_start?: string | null; pp_id: string; reference_consent?: boolean; reference_contact?: string | null; reference_name?: string | null; role: string; scope_summary?: string | null; scope_tags?: Json | null; value_usd?: number | null }
        Update: { contract_title?: string; cpars_rating?: string | null; created_at?: string; customer?: string; embedding?: string | null; naics?: Json | null; outcomes?: Json | null; partner_provided?: boolean; period_end?: string | null; period_start?: string | null; pp_id?: string; reference_consent?: boolean; reference_contact?: string | null; reference_name?: string | null; role?: string; scope_summary?: string | null; scope_tags?: Json | null; value_usd?: number | null }
        Relationships: []
      }
      requirements: {
        Row: { confidence: string | null; coverage_status: string; findings: Json | null; id: number; obligation: string; page: number | null; proposal_section: string | null; proposal_volume: string | null; req_id: string; requirement_text: string; solicitation_id: number | null; source_section: string | null; source_type: string }
        Insert: { confidence?: string | null; coverage_status?: string; findings?: Json | null; id?: never; obligation: string; page?: number | null; proposal_section?: string | null; proposal_volume?: string | null; req_id: string; requirement_text: string; solicitation_id?: number | null; source_section?: string | null; source_type: string }
        Update: { confidence?: string | null; coverage_status?: string; findings?: Json | null; id?: never; obligation?: string; page?: number | null; proposal_section?: string | null; proposal_volume?: string | null; req_id?: string; requirement_text?: string; solicitation_id?: number | null; source_section?: string | null; source_type?: string }
        Relationships: [{ foreignKeyName: "requirements_solicitation_id_fkey"; columns: ["solicitation_id"]; isOneToOne: false; referencedRelation: "solicitations"; referencedColumns: ["id"] }]
      }
      solicitation_pages: {
        Row: { id: number; page: number; solicitation_id: number | null; text: string | null; ucf_section: string | null }
        Insert: { id?: never; page: number; solicitation_id?: number | null; text?: string | null; ucf_section?: string | null }
        Update: { id?: never; page?: number; solicitation_id?: number | null; text?: string | null; ucf_section?: string | null }
        Relationships: [{ foreignKeyName: "solicitation_pages_solicitation_id_fkey"; columns: ["solicitation_id"]; isOneToOne: false; referencedRelation: "solicitations"; referencedColumns: ["id"] }]
      }
      solicitations: {
        Row: { created_at: string; detected_sections: Json | null; extractor: string | null; id: number; mode: string | null; opportunity_id: string | null; page_count: number; source_path: string }
        Insert: { created_at?: string; detected_sections?: Json | null; extractor?: string | null; id?: never; mode?: string | null; opportunity_id?: string | null; page_count?: number; source_path: string }
        Update: { created_at?: string; detected_sections?: Json | null; extractor?: string | null; id?: never; mode?: string | null; opportunity_id?: string | null; page_count?: number; source_path?: string }
        Relationships: [{ foreignKeyName: "solicitations_opportunity_id_fkey"; columns: ["opportunity_id"]; isOneToOne: false; referencedRelation: "opportunities"; referencedColumns: ["notice_id"] }]
      }
    }
    Views: { [_ in never]: never }
    Functions: {
      match_past_performance: {
        Args: { filter_naics?: string; match_count?: number; query_embedding: string }
        Returns: { contract_title: string; cpars_rating: string; customer: string; pp_id: string; role: string; similarity: number }[]
      }
    }
    Enums: { [_ in never]: never }
    CompositeTypes: { [_ in never]: never }
  }
}
