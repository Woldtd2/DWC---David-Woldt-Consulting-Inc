// Supabase Edge Function: samgov-ingest
// Phase 1 (woldt-federal-solutions) — pulls SAM.gov opportunities into public.opportunities.
// See docs/specs/woldt-federal-solutions-phase1-samgov-ingestion.md
//
// Deploy:  supabase functions deploy samgov-ingest --no-verify-jwt
// Secrets: SAM_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY,
//          SAM_NAICS, SAM_POSTED_FROM_DAYS, SAM_PTYPE
// Invoke:  scheduled (cron) POST; supports ?dryRun=1 to map+count without writing.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SAM_API = "https://api.sam.gov/opportunities/v2/search";

const env = (k: string, d = "") => Deno.env.get(k) ?? d;

function mmddyyyy(d: Date): string {
  return `${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getDate()).padStart(2, "0")}/${d.getFullYear()}`;
}

function flattenPoP(p: any): string | null {
  if (!p) return null;
  const city = p.city?.name ?? p.city ?? "";
  const state = p.state?.name ?? p.state?.code ?? p.state ?? "";
  const zip = p.zip ?? "";
  const country = p.country?.name ?? p.country?.code ?? p.country ?? "";
  return [city, state, zip, country].filter(Boolean).join(", ") || null;
}

// Maps one SAM.gov notice to a public.opportunities row.
export function mapNotice(n: any) {
  const deadline: string | null = n.responseDeadLine ?? null;
  return {
    notice_id: n.noticeId,
    source: "sam.gov",
    solicitation_number: n.solicitationNumber ?? null,
    title: n.title ?? "(untitled)",
    agency_path: n.fullParentPathName ?? null,
    notice_type: n.type ?? null,
    base_type: n.baseType ?? null,
    naics: n.naicsCode ?? null,
    classification_code: n.classificationCode ?? null,
    set_aside: n.typeOfSetAside ?? null,
    set_aside_code: n.typeOfSetAsideDescription ?? null,
    posted_date: n.postedDate ?? null,
    response_deadline: deadline,
    response_deadline_tz_present: deadline ? /[+-]\d{2}:?\d{2}|Z$/.test(deadline) : false,
    place_of_performance: flattenPoP(n.placeOfPerformance),
    active: typeof n.active === "string" ? n.active.toLowerCase() === "yes" : !!n.active,
    description_link: typeof n.description === "string" ? n.description : null,
    ui_link: n.uiLink ?? null,
    points_of_contact: n.pointOfContact ?? null,
    raw: n,
  };
}

async function fetchPage(params: URLSearchParams, offset: number) {
  params.set("offset", String(offset));
  const res = await fetch(`${SAM_API}?${params.toString()}`);
  if (!res.ok) throw new Error(`SAM.gov ${res.status}: ${(await res.text()).slice(0, 300)}`);
  return await res.json();
}

Deno.serve(async (req) => {
  const dryRun = new URL(req.url).searchParams.get("dryRun") === "1";
  const apiKey = env("SAM_API_KEY");
  if (!apiKey) return Response.json({ error: "SAM_API_KEY not set" }, { status: 500 });

  const lookback = parseInt(env("SAM_POSTED_FROM_DAYS", "7"), 10);
  const from = new Date(Date.now() - lookback * 86400000);
  const params = new URLSearchParams({
    api_key: apiKey,
    postedFrom: mmddyyyy(from),
    postedTo: mmddyyyy(new Date()),
    limit: "1000",
  });
  if (env("SAM_PTYPE")) params.set("ptype", env("SAM_PTYPE"));
  if (env("SAM_NAICS")) params.set("ncode", env("SAM_NAICS"));

  const supabase = dryRun
    ? null
    : createClient(env("SUPABASE_URL"), env("SUPABASE_SERVICE_ROLE_KEY"));

  let offset = 0, total = Infinity, mapped = 0, upserted = 0, failedPages = 0;
  const errors: string[] = [];

  while (offset < total) {
    let page: any;
    try {
      page = await fetchPage(params, offset);
    } catch (e) {
      failedPages++; errors.push(String(e));
      offset += 1000;
      if (failedPages > 3) break;
      continue;
    }
    total = page.totalRecords ?? 0;
    const rows = (page.opportunitiesData ?? []).map(mapNotice).filter((r: any) => r.notice_id);
    mapped += rows.length;

    if (!dryRun && rows.length) {
      const { error } = await supabase!.from("opportunities").upsert(rows, { onConflict: "notice_id" });
      if (error) errors.push(`upsert@${offset}: ${error.message}`);
      else upserted += rows.length;
    }
    offset += 1000;
    if ((page.opportunitiesData ?? []).length === 0) break;
  }

  return Response.json({ dryRun, total, mapped, upserted, failedPages, errors });
});
